This is a Agent QQ start, skips update.  
  
System Environment:  
Windows 11 + .Net Framework 4.7.2  
  
代理QQ啟動，會略過軟體強迫更新的小程式  
由於不想啟動QQ被強迫更新，所以寫了此程式自用  

